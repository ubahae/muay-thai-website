const locations = [
    {name: "Bangkok", latitude: 13.7563, longitude: 100.5018},
    {name: "Tokyo", latitude: 36.6895, longitude: 139.6917},
    {name: "New York", latitude: 40.7128, longitude: -74.0060},
    {name: "London", latitude: 51.5074, longitude: -0.1278},
    {name: "Paris", latitude: 48.8566, longitude: 2.3522},
]


const weatherContainer = document.getElementById('weather-container');

async function fetchWeather() {

    weatherContainer.innerHTML = '';
    for (const location of locations) {
    const apiUrl = `https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current_weather=true`;

    try {
        let response = await fetch(apiUrl);

        let data = await response.json();

        let temperature = data.current_weather.temperature;
        let windspeed = data.current_weather.windspeed;


        weatherContainer.innerHTML += `
        <h3>Current weather in ${location.name}</h3>
        <p>temperature: ${temperature}Celsius</p>
        <p> Wind speed: ${windspeed} km/h</p>
        <hr>
        
        
        `;
    } catch (error) {
        weatherContainer.innerHTML = `<p> Unable to fetch data.</p>`;
        console.error('Error fetching data:', error);

    }
}

}

fetchWeather();
setInterval(fetchWeather, 600000);